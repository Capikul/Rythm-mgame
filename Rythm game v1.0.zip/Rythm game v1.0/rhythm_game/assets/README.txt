RHYTHM GAME ASSETS
==================

Put your main menu music here:

  main_menu_music.mp3

The MP3 loops automatically while you are in the main menu and stops when you start a song.

Selection sound:
  select.ogg
  select.wav
  select.mp3
  select.flac

If the MP3 or selection sound is missing, the game still runs normally without that audio.
